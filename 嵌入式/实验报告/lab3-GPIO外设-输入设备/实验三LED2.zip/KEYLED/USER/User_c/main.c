#include"stm32f10x.h"
//#include"led.h"
#include "key.h"

//SysTick_Init();

int main(void)
{
	Key_GPIO_Config();
	LED_Init();
	
		while(1)
	{
		if(Key_Scan(GPIOE,GPIO_Pin_0) == KEY_ON)
		{
			LED1( ON );Delay(0x0FFFEF);LED1( OFF );		  
			LED2( ON );Delay(0x0FFFEF);LED2( OFF );			
			LED3( ON );Delay(0x0FFFEF);LED3( OFF );      		
			LED4( ON );Delay(0x0FFFEF);LED4( OFF );				
			LED5( ON );Delay(0x0FFFEF);LED5( OFF );		
			LED6( ON );Delay(0x0FFFEF);LED6( OFF ); 
			LED7( ON );Delay(0x0FFFEF);LED7( OFF ); 			
			LED8( ON );Delay(0x0FFFEF);LED8( OFF ); 
		}
		
		if(Key_Scan(GPIOE,GPIO_Pin_1) == KEY_ON)
		{
			LED1( ON );LED2( OFF );LED3( ON );LED4( OFF );LED5( ON );LED6( OFF );LED7( ON );LED8( OFF );
			Delay(0x0FFFEF);
			LED1( OFF );LED2( ON );LED3( OFF );LED4( ON );LED5( OFF );LED6( ON );LED7( OFF );LED8( ON );
			Delay(0x7FFFFF);
			LED1( ON );LED2( OFF );LED3( ON );LED4( OFF );LED5( ON );LED6( OFF );LED7( ON );LED8( OFF );
			Delay(0x0FFFEF);
			LED1( OFF );LED2( ON );LED3( OFF );LED4( ON );LED5( OFF );LED6( ON );LED7( OFF );LED8( ON );
			LED2( OFF );LED4( OFF );LED6( OFF );LED8( OFF );
		}
		
		if(Key_Scan(GPIOE,GPIO_Pin_2) == KEY_ON)
		{
			LED1( ON );LED2( ON );Delay(0x0FFFEF);LED1( OFF );LED2( OFF );
			LED5( ON );LED6( ON );Delay(0x0FFFEF);LED5( OFF );LED6( OFF );
			LED3( ON );LED4( ON );Delay(0x0FFFEF);LED3( OFF );LED4( OFF );	
			LED7( ON );LED8( ON );Delay(0x0FFFEF);LED7( OFF );LED8( OFF );
		}
		
		if(Key_Scan(GPIOE,GPIO_Pin_3) == KEY_ON)
		{
			LED1( ON );LED8( ON );Delay(0x0FFFEF);LED1( OFF );LED8( OFF );
			LED2( ON );LED7( ON );Delay(0x0FFFEF);LED2( OFF );LED7( OFF );
			LED3( ON );LED6( ON );Delay(0x0FFFEF);LED3( OFF );LED6( OFF );
			LED4( ON );LED5( ON );Delay(0x0FFFEF);LED4( OFF );LED5( OFF );
		}
	}
	
}
