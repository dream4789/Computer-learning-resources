#include"stm32f10x.h"
//#include"led.h"
int main(void)
{
	
	//LED_init();
	//GPIO_ResetBits(GPIOB, led);
	while(1);
}
