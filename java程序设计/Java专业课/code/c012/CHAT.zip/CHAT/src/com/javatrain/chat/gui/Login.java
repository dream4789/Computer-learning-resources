package com.javatrain.chat.gui;

import javax.swing.JFrame;

public class Login {

	public static void main(String[] args) {
			// TODO Auto-generated method stub
			JFrame frame = new LoginFrame();
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setVisible(true);	
	}
}