package com.javatrain.chat.gui;

import javax.swing.JDialog;

public class LookChatRecord extends JDialog {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
